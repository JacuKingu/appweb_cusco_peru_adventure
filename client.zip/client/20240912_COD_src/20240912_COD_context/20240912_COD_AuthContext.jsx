import React, { createContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginUsuario } from '@services/20240912_COD_AuthService';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const storedUser = localStorage.getItem('authToken');
        if (storedUser) {
            setUser(JSON.parse(storedUser));
        }
        setLoading(false);
    }, []);

    const login = async (nombre, contraseña) => {
        try {
            const response = await loginUsuario(nombre, contraseña);
            setUser(response);
            localStorage.setItem('authToken', JSON.stringify(response));
            navigate('/main/home');
        } catch (error) {
            throw new Error(error.message);
        }
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('authToken');
        navigate('/');
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, loading }}>
            {children}
        </AuthContext.Provider>
    );
};

export default AuthContext;
