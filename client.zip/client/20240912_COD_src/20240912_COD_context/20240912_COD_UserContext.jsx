import React, { createContext, useState, useEffect, useContext } from 'react';
import { obtenerUsuarioPorIdYRol } from '@services/20240912_COD_UsuarioService';
import AuthContext from './20240912_COD_AuthContext';

const UserContext = createContext();

export const UserProvider = ({ children }) => {
    const { user } = useContext(AuthContext);
    const [userData, setUserData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user) {
            // Obtener información adicional del usuario utilizando su ID
            obtenerUsuarioPorIdYRol(user.id, user.rol).then((data) => {
                setUserData(data);
                setLoading(false);
            }).catch(() => {
                setUserData(null);
                setLoading(false);
            });
        } else {
            setLoading(false);
        }
    }, [user]);

    return (
        <UserContext.Provider value={{ userData, loading }}>
            {children}
        </UserContext.Provider>
    );
};

export default UserContext;
