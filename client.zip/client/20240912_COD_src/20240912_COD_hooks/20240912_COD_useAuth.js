import { useContext } from 'react';
import AuthContext from '@context/20240912_COD_AuthContext';

const useAuth = () => {
    return useContext(AuthContext);
};

export default useAuth;
