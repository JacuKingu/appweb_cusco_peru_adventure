// index.jsx o App.jsx
import './20240912_COD_styles/20240912_COD_tailwind.css';
