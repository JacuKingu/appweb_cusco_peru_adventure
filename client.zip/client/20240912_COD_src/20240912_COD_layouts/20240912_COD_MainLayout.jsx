// 20240912_COD_layouts/20240912_COD_MainLayout.jsx
import React from 'react';
import Sidebar from '@components/20240912_COD_Sidebar';

const MainLayout = ({ children }) => {
    return (
        <div className="layout">
            <aside className="sidebar">
                <Sidebar />
            </aside>
            <main className="content">
                {children}
            </main>
        </div>
    );
};

export default MainLayout;
