import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { AuthProvider } from '@context/20240912_COD_AuthContext.jsx';
import { UserProvider } from '@context/20240912_COD_UserContext.jsx';
import Routes from './20240912_COD_routes/20240912_COD_Routes.jsx';

const App = () => {
    return (
        <AuthProvider>
            <UserProvider>
                <Router>
                    <Routes />
                </Router>
            </UserProvider>
        </AuthProvider>
    );
};

export default App;
