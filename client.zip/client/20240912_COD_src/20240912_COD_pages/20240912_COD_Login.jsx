import React, { useState } from 'react';
import useAuth from '@hooks/20240912_COD_useAuth';

const Login = () => {
    const [nombre, setNombre] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const { login } = useAuth();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        try {
            await login(nombre, password);
        } catch (err) {
            setError('Error en el inicio de sesión');
        }
    };

    return (
        <div className="flex justify-center items-center h-screen">
            <form onSubmit={handleSubmit} className="w-80 p-4 bg-white shadow-md rounded">
                <h1 className="text-2xl font-bold mb-4">Iniciar Sesión</h1>
                <input
                    type="text"
                    placeholder="Nombre"
                    value={nombre}
                    onChange={(e) => setNombre(e.target.value)}
                    className="w-full p-2 mb-4 border"
                />
                <input
                    type="password"
                    placeholder="Contraseña"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full p-2 mb-4 border"
                />
                {error && <div className="text-red-500 mb-4">{error}</div>}
                <button type="submit" className="w-full p-2 bg-blue-500 text-white">
                    Iniciar Sesión
                </button>
            </form>
        </div>
    );
};

export default Login;
