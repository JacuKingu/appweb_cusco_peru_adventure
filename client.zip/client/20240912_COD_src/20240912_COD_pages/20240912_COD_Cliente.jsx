// 20240912_COD_Clients.jsx
import React from 'react';

const Cliente = () => {
  return (
    <div className="min-h-screen p-6 bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">Gestión de Clientes</h1>
      <p className="text-lg">Aquí puedes gestionar todos los clientes de la empresa.</p>
      {/* Aquí puedes agregar una tabla o lista de clientes más adelante */}
    </div>
  );
};

export default Cliente;
