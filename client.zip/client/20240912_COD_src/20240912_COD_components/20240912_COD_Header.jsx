// 20240912_COD_Header.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';

const Header = () => {
  const history = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('authToken'); // Eliminar el token de autenticación
    history.push('/'); // Redirigir al login
  };

  return (
    <div className="bg-gray-700 text-white p-4 flex justify-between items-center">
      <h1 className="text-lg font-bold">Dashboard</h1>
      <button
        className="bg-red-500 px-4 py-2 rounded hover:bg-red-700"
        onClick={handleLogout}
      >
        Cerrar Sesión
      </button>
    </div>
  );
};

export default Header;
