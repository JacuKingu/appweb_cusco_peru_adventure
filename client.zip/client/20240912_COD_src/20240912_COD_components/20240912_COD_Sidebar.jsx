import React from 'react';
import { NavLink } from 'react-router-dom';

const Sidebar = () => {
    return (
        <div className="w-64 bg-blue-900 text-white flex-shrink-0">
            <div className="p-4 text-xl font-bold">Menú Principal</div>
            <nav className="mt-4">
                <NavLink
                    to="/main/home"
                    className="block py-2.5 px-4 hover:bg-blue-700"
                    activeClassName="bg-blue-700"
                >
                    Inicio
                </NavLink>
                <NavLink
                    to="/main/cliente"
                    className="block py-2.5 px-4 hover:bg-blue-700"
                    activeClassName="bg-blue-700"
                >
                    Gestión de Clientes
                </NavLink>
                {/* Otras rutas del menú */}
            </nav>
        </div>
    );
};

export default Sidebar;
