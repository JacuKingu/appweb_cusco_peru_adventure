// 20240912_COD_Routes.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MainLayout from '../layouts/20240912_COD_MainLayout';
import Home from '../pages/20240912_COD_Home';
import Clients from '../pages/20240912_COD_Clients';
import Tours from '../pages/20240912_COD_Tours';
import Groups from '../pages/20240912_COD_Groups';
import Reservations from '../pages/20240912_COD_Reservations';
import Recommendations from '../pages/20240912_COD_Recommendations';
import Passports from '../pages/20240912_COD_Passports';
import Admin from '../pages/20240912_COD_Admin';
import Login from '../pages/20240912_COD_Login';

const AppRoutes = () => {
    return (
        <Router>
            <Routes>
                {/* Ruta para la página de login */}
                <Route path="/" element={<Login />} />
                {/* Rutas protegidas con el layout principal */}
                <Route path="/" element={<MainLayout />}>
                    <Route path="home" element={<Home />} />
                    <Route path="clients" element={<Clients />} />
                    <Route path="tours" element={<Tours />} />
                    <Route path="groups" element={<Groups />} />
                    <Route path="reservations" element={<Reservations />} />
                    <Route path="recommendations" element={<Recommendations />} />
                    <Route path="passports" element={<Passports />} />
                    <Route path="admin" element={<Admin />} />
                </Route>
            </Routes>
        </Router>
    );
};

export default AppRoutes;
