import React, { lazy, Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';
import MainLayout from '@layouts/20240912_COD_MainLayout';
import Login from '@pages/20240912_COD_Login';
import PrivateRoute from './20240912_COD_PrivateRoute';

const Home = lazy(() => import('@pages/20240912_COD_Home'));
const Cliente = lazy(() => import('@pages/20240912_COD_Cliente'));
const Tour = lazy(() => import('@pages/20240912_COD_Tour'));
// Importar otros componentes de forma lazy

const AppRoutes = () => {
    return (
        <Suspense fallback={<div>Cargando...</div>}>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route
                    path="/main/*"
                    element={
                        <PrivateRoute>
                            <MainLayout />
                        </PrivateRoute>
                    }
                >
                    <Route path="home" element={<Home />} />
                    <Route path="cliente" element={<Cliente />} />
                    <Route path="tour" element={<Tour />} />
                    {/* Otras rutas protegidas */}
                </Route>
            </Routes>
        </Suspense>
    );
};

export default AppRoutes;
