/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './20240912_COD_src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

